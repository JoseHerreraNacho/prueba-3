from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('agregar/', views.agregar_carrito, name='agregar_carrito'),
    path('carrito/', views.ver_carrito, name='ver_carrito'),
    path('registro/', views.registro, name='registro'),
    path('inicio_sesion/', views.inicio_sesion, name='inicio_sesion'),
    path('perfil/', views.perfil, name='perfil'),
    path('formulario_espanol/', views.formulario_espanol, name='formulario_espanol'),
    path('formulario_chino/', views.formulario_chino, name='formulario_chino'),
    path('decoracion/', views.decoracion, name='decoracion'),
    path('artesania/', views.artesania, name='artesania'),
    path('juguetes/', views.juguetes, name='juguetes'),
]
