from django.shortcuts import render
from .models import Producto

def index(request):
    productos = Producto.objects.all()  # Asegúrate de importar el modelo Producto
    return render(request, 'carrito/index.html', {'productos': productos})

def agregar_carrito(request):
    # Lógica para agregar al carrito
    pass

def ver_carrito(request):
    # Lógica para ver el carrito
    pass

def registro(request):
    # Lógica para la página de registro
    return render(request, 'carrito/registro.html')

def inicio_sesion(request):
    # Lógica para la página de inicio de sesión
    return render(request, 'carrito/inicioSesion.html')

def perfil(request):
    # Lógica para la página de perfil
    return render(request, 'carrito/Perfil.html')

def formulario_espanol(request):
    # Lógica para el formulario en español
    return render(request, 'carrito/formulario_espanol.html')

def formulario_chino(request):
    # Lógica para el formulario en chino
    return render(request, 'carrito/formulario_chino.html')

def decoracion(request):
    # Lógica para la página de decoración
    return render(request, 'carrito/decoracion.html')

def artesania(request):
    # Lógica para la página de artesanía
    return render(request, 'carrito/artesania.html')

def juguetes(request):
    # Lógica para la página de juguetes
    return render(request, 'carrito/juguetes.html')
